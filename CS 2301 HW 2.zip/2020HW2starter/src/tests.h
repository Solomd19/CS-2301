/*
 * tests.h
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#ifndef TESTS_H_
#define TESTS_H_


#include "production.h"
bool tests();

bool testInitBoard();
bool testPrintSpace();
bool testMakeMarker();
bool testMoveMarker();
bool testLinkedList();


#endif /* TESTS_H_ */
