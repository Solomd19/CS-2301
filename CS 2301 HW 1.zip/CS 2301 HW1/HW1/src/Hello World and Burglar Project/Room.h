//
// Created by supad on 10/28/2020.
//

#ifndef UNTITLED_ROOM_H
#define UNTITLED_ROOM_H
#include "House.h"
#include "Layout.h"
#include <stdbool.h>
typedef struct {

}Room;

bool isOpen(Room*);
bool haveTreasure(Room*);

#endif //UNTITLED_ROOM_H
