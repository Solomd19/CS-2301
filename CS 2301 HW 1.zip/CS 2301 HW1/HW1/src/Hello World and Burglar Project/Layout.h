//
// Created by supad on 10/28/2020.
//

#ifndef UNTITLED_LAYOUT_H
#define UNTITLED_LAYOUT_H
#include "House.h"
#include "Room.h"
typedef struct {

}Layout;

int countRooms(Layout*);
Room* getFirstRoom(Layout*);

#endif //UNTITLED_LAYOUT_H
