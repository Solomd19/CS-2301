/*
 * production.h
 *
 *  Created on: Jul 4, 2019
 *      Author: Drew Solomon
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include <string.h>//strncpy
#include <stdlib.h>//strtol




#define FILENAMELENGTHALLOWANCE 50

bool production(int argc, char* argv[]);



#endif /* PRODUCTION_H_ */
