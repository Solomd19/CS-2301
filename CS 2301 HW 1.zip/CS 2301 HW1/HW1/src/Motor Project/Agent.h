//
// Created by supad on 10/30/2020.
//

#ifndef UNTITLED_AGENT_H
#define UNTITLED_AGENT_H

typedef struct {
} Agent;

void setTimeInterval(Agent);
void setEndLoc(int x,int y,int z);

#endif //UNTITLED_AGENT_H
