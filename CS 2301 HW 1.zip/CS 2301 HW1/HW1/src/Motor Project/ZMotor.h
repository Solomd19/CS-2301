//
// Created by supad on 10/30/2020.
//

#ifndef UNTITLED_ZMOTOR_H
#define UNTITLED_ZMOTOR_H

typedef struct {
} ZMotor;

void setZVel(int vz);
void Go(int timeInterval);

#endif //UNTITLED_ZMOTOR_H
