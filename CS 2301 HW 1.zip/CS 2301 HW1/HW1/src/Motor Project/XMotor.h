//
// Created by supad on 10/30/2020.
//

#ifndef UNTITLED_XMOTOR_H
#define UNTITLED_XMOTOR_H

typedef struct {
} XMotor;

void setXVel(int vx);
void Go(int timeInterval);

#endif //UNTITLED_XMOTOR_H
