//
// Created by supad on 10/30/2020.
//

#ifndef UNTITLED_YMOTOR_H
#define UNTITLED_YMOTOR_H

typedef struct {
} YMotor;

void setYVel(int vy);
void Go(int timeInterval);

#endif //UNTITLED_YMOTOR_H
