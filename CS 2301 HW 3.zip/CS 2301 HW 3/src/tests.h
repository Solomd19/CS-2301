/*
 * tests.h
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#ifndef TESTS_H_
#define TESTS_H_


#include "production.h"
bool tests();



bool testCallLetterNum();
bool testInitCard();
bool testCardSearch();
bool testCallHistory();


#endif /* TESTS_H_ */
